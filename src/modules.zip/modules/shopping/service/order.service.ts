import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import dayjs from 'dayjs';
import { Between } from 'typeorm';
import { Users } from '../../user/entities/users.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Order, OrderStatus } from '../entities/order.entity';
import { Repository, DeepPartial } from 'typeorm';
import { OrderItem } from '../entities/order-item.entity';
import { CartService } from './cart.service';
import { CreateOrderDto } from '../dto/create-order.dto';
import { Promotion } from '../../promotion/entities/promotion.entity';

@Injectable()
export class OrderService {
  constructor(
    @InjectRepository(Order) private readonly orderRepo: Repository<Order>,
    @InjectRepository(OrderItem)
    private readonly orderItemRepo: Repository<OrderItem>,
    @InjectRepository(Users)
    private readonly userRepo: Repository<Users>,
    @InjectRepository(Promotion)
    private readonly promoRepo: Repository<Promotion>,
    private readonly cartService: CartService,
  ) {}

  async getAllOrders(): Promise<Order[]> {
    return this.orderRepo.find({
      relations: ['user', 'items', 'items.product', 'promotion'],
      order: { createdAt: 'DESC' },
    });
  }

  async createOrderFromCart(
    userId: string,
    dto: CreateOrderDto,
  ): Promise<Order> {
    const cart = await this.cartService.getOrCreateCart(userId);
    if (!cart.items?.length) throw new BadRequestException('Cart is empty');

    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException('User not found');
    }

    const orderNumber = this.generateOrderNumber();

    const order = this.orderRepo.create({
      user: user,
      orderNumber,
      status: OrderStatus.PENDING,
      total: 0,
      discountAmount: 0,
      items: [],
      paymentMethod: dto.paymentMethod || 'COD',
      shippingAddress: dto.shippingAddress,
      notes: dto.notes,
    } as DeepPartial<Order>);

    let total = 0;
    order.items = cart.items.map((i) => {
      const unitPrice = Number(i.unitPrice ?? i.product.price);
      total += unitPrice * i.quantity;
      return this.orderItemRepo.create({
        product: i.product,
        quantity: i.quantity,
        unitPrice,
      });
    });

    let discountAmount = 0;
    let promotion: Promotion | null = null;

    if (dto.promotionCode) {
      promotion = await this.promoRepo.findOne({
        where: { code: dto.promotionCode, isActive: true },
      });

      if (!promotion) {
        throw new BadRequestException('Invalid promotion code');
      }

      const now = new Date();
      if (
        (promotion.startDate && now < promotion.startDate) ||
        (promotion.endDate && now > promotion.endDate)
      ) {
        throw new BadRequestException('Promotion code expired or inactive');
      }

      if (promotion.minOrderValue && total < Number(promotion.minOrderValue)) {
        throw new BadRequestException(
          `Minimum order value for this promotion is ${promotion.minOrderValue}₫`,
        );
      }

      if (promotion.discountPercent) {
        discountAmount = Math.floor(
          (total * Number(promotion.discountPercent)) / 100,
        );
      } else if (promotion.discountAmount) {
        discountAmount = Number(promotion.discountAmount);
      }

      total -= discountAmount;

      order.promotion = promotion;
    }

    order.discountAmount = discountAmount;
    order.total = Number(total.toFixed(2));

    const saved = await this.orderRepo.save(order);

    await this.cartService.clear(userId);

    const result = await this.orderRepo.findOne({
      where: { id: saved.id },
      relations: ['items', 'items.product', 'promotion'],
    });
    if (!result) throw new NotFoundException('Order not found after save');
    return result;
  }

  async listUserOrders(userId: string): Promise<Order[]> {
    return this.orderRepo.find({
      where: { user: { id: userId } },
      relations: ['items', 'items.product'],
      order: { createdAt: 'DESC' },
    });
  }

  async getOrderDetail(userId: string, orderId: string): Promise<Order> {
    const order = await this.orderRepo.findOne({
      where: { id: orderId, user: { id: userId } },
      relations: ['items', 'items.product'],
    });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }
  async getOrderDetailAdmin(orderId: string): Promise<Order> {
    const order = await this.orderRepo.findOne({
      where: { id: orderId },
      relations: ['items', 'items.product', 'user'],
    });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  async updateStatus(orderId: string, status: OrderStatus): Promise<Order> {
    const order = await this.orderRepo.findOne({
      where: { id: orderId },
      relations: ['items', 'items.product'],
    });
    if (!order) throw new NotFoundException('Order not found');
    order.status = status;
    return this.orderRepo.save(order);
  }

  async cancelOrder(userId: string, orderId: string): Promise<Order> {
    const order = await this.orderRepo.findOne({
      where: { id: orderId, user: { id: userId } },
      relations: ['items', 'items.product'],
    });
    if (!order) throw new NotFoundException('Order not found');

    if (order.status !== OrderStatus.PENDING) {
      throw new BadRequestException(
        'Can only cancel orders with PENDING status',
      );
    }

    order.status = OrderStatus.CANCELED;
    return this.orderRepo.save(order);
  }

  private generateOrderNumber(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, '0');
    return `ORD${timestamp}${random}`;
  }

  async updatePayosCode(orderId: string, payosCode: number) {
    await this.orderRepo.update(orderId, { payosOrderCode: payosCode });
  }

  async findByPayosCode(payosCode: number) {
    return this.orderRepo.findOne({ where: { payosOrderCode: payosCode } });
  }

  async getStatistics(period: 'day' | 'week' | 'month' = 'week') {
    try {
      const now = dayjs();
      let startDate = now.startOf('week');

      if (period === 'day') startDate = now.startOf('day');
      else if (period === 'month') startDate = now.startOf('month');
      else if (period !== 'week') {
        throw new BadRequestException('Invalid period value');
      }

      if (!startDate.isValid() || !now.isValid()) {
        throw new BadRequestException('Invalid date range');
      }

      const start = startDate.toDate();
      const end = now.toDate();

      const orders = await this.orderRepo.find({
        where: { createdAt: Between(start, end) },
      });

      const totalRevenue = orders.reduce(
        (sum, o) => sum + Number(o.total || 0),
        0,
      );
      const totalOrders = orders.length;
      const completedOrders = orders.filter(
        (o) =>
          o.status === OrderStatus.DELIVERED || o.status === OrderStatus.PAID,
      ).length;

      const days: Record<string, number> = {};
      const diffDays = period === 'month' ? now.diff(startDate, 'day') + 1 : 7;

      for (let i = 0; i < diffDays; i++) {
        const date = startDate.add(i, 'day').format('YYYY-MM-DD');
        days[date] = 0;
      }

      orders.forEach((order) => {
        const date = dayjs(order.createdAt).format('YYYY-MM-DD');
        if (days[date] !== undefined) {
          days[date] += Number(order.total || 0);
        }
      });

      const statusChart = orders.reduce(
        (acc, o) => {
          acc[o.status] = (acc[o.status] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>,
      );

      return {
        totalRevenue,
        totalOrders,
        completedOrders,
        chart: Object.entries(days).map(([date, revenue]) => ({
          date,
          revenue,
        })),
        statusChart,
      };
    } catch (error) {
      console.error(' Error in getStatistics():', error);
      return {
        totalRevenue: 0,
        totalOrders: 0,
        completedOrders: 0,
        chart: [],
        statusChart: {},
      };
    }
  }
}
